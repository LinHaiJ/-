#include "fun.h"
#include "headfile.h"

uint32_t freA_meature,freB_meature;
uint32_t capture_A,capture_B;
int freA,freB;
uint8_t data_mode = 0;//数据界面转换
uint8_t lcd_mode; //0数据界面 -1参数界面 -2统计界面
uint8_t lcd_last_mode;
uint8_t para_select;

uint8_t B3_pressed;
uint16_t B3_press_timer;

int PX = 0;
uint16_t PD = 1000;
uint16_t PH = 5000;

uint16_t timerA_3s; //超限3s
uint16_t timerB_3s;
int freA_max, freA_min;
int freB_max, freB_min;

uint8_t NDA=0,NDB=0,NHA=0,NHB=0;


void led_show(uint8_t led, uint8_t led_mode)
{
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_SET);
	if(led_mode)
	{
		HAL_GPIO_WritePin(GPIOC, (GPIO_PIN_8 << (led - 1)), GPIO_PIN_RESET);
	}
	else
	{
		HAL_GPIO_WritePin(GPIOC, (GPIO_PIN_8 << (led - 1)), GPIO_PIN_SET);
	}
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_2, GPIO_PIN_RESET);
}

uint8_t B1_state;
uint8_t B2_state;
uint8_t B3_state;
uint8_t B4_state;
uint8_t B1_last_state, B2_last_state, B3_last_state, B4_last_state;

void key_scan()
{
	B1_state = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0);
	B2_state = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1);
	B3_state = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_2);
	B4_state = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0);
	
	if(B1_state == 0 && B1_last_state == 1)
	{
		if(lcd_mode == 1)
		{
			if(para_select == 0) 
			{
				if(PD >= 1000) PD = 1000;
				else PD += 100;
			}
			else if(para_select == 1)
			{
				if(PH >= 10000) PH = 10000;
				else PH += 100;
			}
			else if(para_select == 2)
			{
				if(PX >= 1000) PX = 1000;
				else PX += 100;
			}
		}
	}
	if(B2_state == 0 && B2_last_state == 1)
	{
					if(para_select == 0) 
			{
				if(PD <= 100) PD = 100;
				else PD -= 100;
			}
			else if(para_select == 1)
			{
				if(PH <= 1000) PH = 1000;
				else PH -= 100;
			}
			else if(para_select == 2)
			{
				if(PX <= -1000) PX = -1000;
				else PX -= 100;
			}
	}
	if(B3_state == 0 && B3_last_state == 1)
	{
		if(lcd_mode == 0)
		{
			data_mode++;
			data_mode = data_mode % 2; 
		}
		else if(lcd_mode == 1)
		{
			para_select++;
			para_select = para_select % 3; 
		}
		if(lcd_mode == 2)
		{
			B3_pressed = 1;
			B3_press_timer = 0;
		}					
	}
	else if(B3_state == 1 && B3_last_state == 0)
	{
		if(B3_press_timer > 100)
		{
			NDA=0;NDB=0;NHA=0;NHB=0;
		}
	}
	if(B4_state == 0 && B4_last_state == 1)
	{
		lcd_mode++;
		lcd_mode = lcd_mode % 3;
		if(lcd_mode == 1)
		{
			para_select = 0;
		}
		if(lcd_mode == 0)
		{
			data_mode = 0;
		}
	}
	
	
	B1_last_state = B1_state;
	B2_last_state = B2_state;
	B3_last_state = B3_state;
	B4_last_state = B4_state;
	
}

char text[20];


void data_show()
{
	sprintf(text, "        DATA       ");
	LCD_DisplayStringLine(Line1 , (uint8_t *)text);
	if(data_mode == 0)
	{
		if(freA < 0)
		{
			sprintf(text, "     A=NULL       ");

		}
		else if(freA > 0 && freA < 1000)
		{
			//sprintf(text, "     A=%dHz       ",freA_meature);
			sprintf(text, "     A=%dHz       ",freA);

		}
		else if(freA > 1000)
		{
			float tempA = (float)freA/1000.0;
			sprintf(text, "     A=%.2fKHz     ",tempA);
			//sprintf(text, "     A=%dHz       ",freA_meature);
		}
	LCD_DisplayStringLine(Line3 , (uint8_t *)text);
		if(freB < 0)
		{
			sprintf(text, "     B=NULL       ");

		}
		else if(freB > 0 && freB < 1000)
		{
			sprintf(text, "     B=%dHz       ",freB_meature);
			//sprintf(text, "     B=%dHz       ",freB);

		}
		else if(freB > 1000)
		{
			float tempB = (float)freB/1000.0;
			//sprintf(text, "     B=%dHz       ",freB_meature);
			sprintf(text, "     B=%.2fKHz     ",tempB);
		}
		LCD_DisplayStringLine(Line4 , (uint8_t *)text);
	}
	else if(data_mode == 1)
	{
		float perA = 1.0/freA * 1000000.0;
		float perB = 1.0/freB * 1000000.0;
		
		if(perA < 0)
		{
			sprintf(text, "     A=NULL       ");
		}
		if(perA > 1000)
		{
			float temp_perA = perA/1000;
			sprintf(text, "     A=%.2fmS     ",temp_perA);
		}
		else if(perA > 0 && perA < 1000)
		{
			sprintf(text, "     A=%.0fuS     ", perA);
		}
		LCD_DisplayStringLine(Line3 , (uint8_t *)text);
		
		if(perB < 0)
		{
			sprintf(text, "     B=NULL       ");
		}
		if(perB > 1000)
		{
			float temp_perB = perB/1000;
			sprintf(text, "     B=%.2fmS     ",temp_perB);
		}
		else if(perB > 0 && perB < 1000)
		{
			sprintf(text, "     B=%.0fuS     ", perB);
		}
		LCD_DisplayStringLine(Line4 , (uint8_t *)text);
		
		
	}

}

void para_show()
{
	sprintf(text, "        PARA       ");
	LCD_DisplayStringLine(Line1 , (uint8_t *)text);
	sprintf(text, "     PD=%dHz       ", PD);
	LCD_DisplayStringLine(Line3 , (uint8_t *)text);
	sprintf(text, "     PH=%dHz       ", PH);
	LCD_DisplayStringLine(Line4 , (uint8_t *)text);
	sprintf(text, "     PX=%dHz       ", PX);
	LCD_DisplayStringLine(Line5 , (uint8_t *)text);
	
}

void recd_show()
{
	sprintf(text, "        RECD       ");
	LCD_DisplayStringLine(Line1 , (uint8_t *)text);
	sprintf(text, "     NDA=%d       ", NDA);
	LCD_DisplayStringLine(Line3 , (uint8_t *)text);
	sprintf(text, "     NDB=%d       ", NDB);
	LCD_DisplayStringLine(Line4 , (uint8_t *)text);
	sprintf(text, "     NHA=%d       ", NHA);
	LCD_DisplayStringLine(Line5 , (uint8_t *)text);
	sprintf(text, "     NHB=%d       ", NHB);
	LCD_DisplayStringLine(Line6 , (uint8_t *)text);
	
}


void lcd_show()
{
	if(lcd_mode != lcd_last_mode)
	{
		LCD_Clear(Black);
		LCD_SetBackColor(Black);
		LCD_SetTextColor(White);
		lcd_last_mode = lcd_mode;
	}
	if(lcd_mode == 0)
	{
		data_show();
	}
	else if(lcd_mode == 1)
	{
		para_show();
	}
	else if(lcd_mode == 2)
	{
		recd_show();
	}
}


uint8_t NHA_flag, NHB_flag;
void change()
{
	if(NHA_flag == 0)
	{
		if(freA > PH)
		{
			NHA++;
			NHA_flag = 1;
		}
	}
	else	
	{
		if(freA < PH)				//这样在freA比PH大时只会增加一次
		{
			NHA_flag = 0;
		}
	}
	
		if(NHB_flag == 0)
	{
		if(freB > PH)
		{
			NHB++;
			NHB_flag = 1;
		}
	}
	else	
	{
		if(freB < PH)				//这样在freB比PH大时只会增加一次
		{
			NHB_flag = 0;
		}
	}
}

void led_disp()
{
	if(lcd_mode == 0) led_show(1, 1);
	else led_show(1, 0);
	if(freA > PH) led_show(2, 1);
	else led_show(2, 0);
	if(freB > PH) led_show(3, 1);
	else led_show(3, 0);
	if((NDA >= 3) || (NDB >= 3)) led_show(8, 1);
	else led_show(8, 0);
	
}



void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
	if(htim->Instance == TIM2)
	{
		capture_A = HAL_TIM_ReadCapturedValue(&htim2, TIM_CHANNEL_1) + 1;
		freA_meature = 1000000 / capture_A;
	}
	if(htim->Instance == TIM3)
	{
		capture_B = HAL_TIM_ReadCapturedValue(&htim3, TIM_CHANNEL_1) + 1;
		freB_meature = 1000000 / capture_B;
	}
}

uint16_t timer_100ms;


void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim->Instance == TIM6)
	{
		timer_100ms++;
		if(timer_100ms >= 10)
		{
			timer_100ms = 0;
			freA = freA_meature + PX;
			freB = freB_meature + PX;
		}
	}
	if(freA > 0)  //因为一开始freA赋值为0，会导致freA_min不可能出现大于freA的情况，避免一上点NDA马上+1
	{
		if(timerA_3s == 0)
		{
			freA_max = freA;
			freA_min = freA;
		}
		else
		{
			if(freA > freA_max) freA_max = freA;
			if(freA < freA_min) freA_min = freA;
		}
		timerA_3s++;
	}
	
	if(freB > 0)
	{
		if(timerB_3s == 0)
		{
			freB_max = freB;
			freB_min = freB;
		}
		else
		{
			if(freB > freB_max) freB_max = freB;
			if(freB < freB_min) freB_min = freB;
		}
		timerB_3s++;
	}
	
	if(timerA_3s >= 300)
	{
		timerA_3s = 0;
		if((freA_max - freA_min) > PD) NDA++;
		freA_max = freA;
		freA_min = freA;
	}
	
		if(timerB_3s >= 300)
	{
		timerB_3s = 0;
		if((freB_max - freB_min) > PD) NDB++;
		freB_max = freB;
		freB_min = freB;
	}
	
	if(B3_pressed)
	{
		B3_press_timer++;
	}
	
}






#ifndef __FUN_H
#define __FUN_H

#include "stm32g4xx.h"
extern uint32_t freA_meature,freB_meature;
extern int PX;
extern int freA,freB;
extern uint8_t data_mode;
extern uint8_t i;
extern uint8_t NDA,NDB,NHA,NHB;


void led_show(uint8_t led, uint8_t led_mode);
void key_scan();
void lcd_show();
void data_show();
void para_show();
void recd_show();
void change();
void led_disp();

#endif
#ifndef __HEADFILE_H
#define __HEADFILE_H

#include "stm32g4xx.h"
#include "fun.h"
#include "main.h"
#include "string.h"
#include "stdio.h"
#include "stdint.h"

#include "tim.h"
#include "gpio.h"
#include "lcd.h"

#endif